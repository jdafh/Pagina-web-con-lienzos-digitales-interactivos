// === Gestión de Retos PaintPlay ===

// Cargar progreso guardado al abrir la página
document.addEventListener("DOMContentLoaded", () => {
  const saved = JSON.parse(localStorage.getItem("retosCumplidos")) || [];
  document.querySelectorAll(".reto-card").forEach(card => {
    const id = parseInt(card.dataset.id);
    const button = card.querySelector(".btn-reto");
    if (saved.includes(id)) {
      marcarCumplido(button, true);
    }
  });
});

// Alternar estado de reto (cumplido / pendiente)
function toggleReto(id) {
  let retos = JSON.parse(localStorage.getItem("retosCumplidos")) || [];
  const index = retos.indexOf(id);
  const card = document.querySelector(`.reto-card[data-id='${id}']`);
  const button = card.querySelector(".btn-reto");

  if (index === -1) {
    retos.push(id);
    marcarCumplido(button, true);
  } else {
    retos.splice(index, 1);
    marcarCumplido(button, false);
  }

  localStorage.setItem("retosCumplidos", JSON.stringify(retos));
}

// Cambiar el texto y estilo del botón
function marcarCumplido(button, cumplido) {
  if (cumplido) {
    button.textContent = "✅ Cumplido";
    button.classList.add("cumplido");
  } else {
    button.textContent = "Pendiente";
    button.classList.remove("cumplido");
  }
}
// Marcar reto automáticamente (sin botón)
function completarRetoAutomatico(id) {
  let retos = JSON.parse(localStorage.getItem("retosCumplidos")) || [];

  if (!retos.includes(id)) {
    retos.push(id);
    localStorage.setItem("retosCumplidos", JSON.stringify(retos));

    const card = document.querySelector(`.reto-card[data-id='${id}']`);
    if (card) {
      const button = card.querySelector(".btn-reto");
      marcarCumplido(button, true);
    }
  }
}

