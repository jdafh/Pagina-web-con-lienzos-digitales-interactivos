// --- Script de Pintura y lógica global ---
const canvas = document.getElementById("paintCanvas");
let ctx;
if (canvas) ctx = canvas.getContext("2d");

let painting = false;
let brushColor = "#000000";
let brushSize = 5;

let undoStack = [];
let redoStack = [];

function saveState() {
  if (!canvas) return;
  undoStack.push(canvas.toDataURL());
  if (undoStack.length > 20) undoStack.shift();
}

function Deshacer() {
  if (!canvas || undoStack.length === 0) return;
  redoStack.push(canvas.toDataURL());
  let imgData = undoStack.pop();
  if (!imgData) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    return;
  }
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let img = new Image();
  img.src = imgData;
  img.onload = () => ctx.drawImage(img, 0, 0);
}

function Rehacer() {
  if (!canvas || redoStack.length === 0) return;
  undoStack.push(canvas.toDataURL());
  let imgData = redoStack.pop();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let img = new Image();
  img.src = imgData;
  img.onload = () => ctx.drawImage(img, 0, 0);
}


if (canvas) {
  canvas.addEventListener("mousedown", startPosition);
  canvas.addEventListener("mouseup", endPosition);
  canvas.addEventListener("mousemove", draw);
}

function startPosition(e) {
  painting = true;
  saveState();
  draw(e);
}

function endPosition() {
  painting = false;
  if (ctx) ctx.beginPath();
}

function draw(e) {
  if (!painting || !ctx) return;
  ctx.lineWidth = brushSize;
  ctx.lineCap = "round";
  ctx.strokeStyle = brushColor;
  ctx.lineTo(e.offsetX, e.offsetY);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(e.offsetX, e.offsetY);
}

// Controles de color y tamaño
const colorPicker = document.getElementById("colorPicker");
if (colorPicker) colorPicker.addEventListener("input", e => { brushColor = e.target.value; });

const sizePicker = document.getElementById("sizePicker");
if (sizePicker) sizePicker.addEventListener("input", e => { brushSize = e.target.value; });

function clearCanvas() {
  if (!ctx || !canvas) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function exportPNG() {
  if (!canvas) return;
  const link = document.createElement('a');
  link.download = 'mi_obra.png';
  link.href = canvas.toDataURL();
  link.click();
}

function saveToGallery() {
  if (!canvas) return;
  const dataUrl = canvas.toDataURL();
  let gallery = JSON.parse(localStorage.getItem("gallery")) || [];
  gallery.push(dataUrl);
  localStorage.setItem("gallery", JSON.stringify(gallery));
  loadGallery();
  updateProfile();
  alert("Obra guardada en la galería");
}

function loadGallery() {
  let gallery = JSON.parse(localStorage.getItem("gallery")) || [];
  const galleryGrid = document.getElementById("galleryGrid");
  if (!galleryGrid) return;
  galleryGrid.innerHTML = "";
  gallery.forEach(imgData => {
    let img = document.createElement("img");
    img.src = imgData;
    img.className = "border shadow";
    galleryGrid.appendChild(img);
  });
}

function updateProfile() {
  let gallery = JSON.parse(localStorage.getItem("gallery")) || [];
  const worksCount = document.getElementById("worksCount");
  if (worksCount) worksCount.textContent = gallery.length;
}

// Inicializar en páginas relevantes
loadGallery();
updateProfile();

const editor = document.getElementById("editor");



